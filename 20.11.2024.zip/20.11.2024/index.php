<?php
// Функция для загрузки данных из файла .ini
function load_products_from_ini($filename) {
    $products = parse_ini_file($filename, true);
    $result = [];

    foreach ($products as $product) {
        $result[] = $product;
    }
    
    return $result;
}

// Функция для отображения карточки товара
function display_product_card($product) {
    echo "<div class='product-card'>";
    echo "<h2>" . htmlspecialchars($product['name']) . "</h2>";
    echo "<p>ID: " . htmlspecialchars($product['id']) . "</p>";
    echo "<p>Описание: " . htmlspecialchars($product['description']) . "</p>";
    echo "<p>Цена: " . htmlspecialchars($product['price']) . " руб.</p>";
    echo "<p>Количество на складе: " . htmlspecialchars($product['stock']) . "</p>";
    echo "</div>";
}

// Функция для отображения всех товаров
function display_all_products($products) {
    foreach ($products as $product) {
        display_product_card($product);
    }
}

// Загрузка данных о товарах
$products = load_products_from_ini('products.ini');

// Отображение товаров на странице
?>
<!DOCTYPE html>
<html lang="ru">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Карточки товаров</title>
    <link rel="stylesheet" href="style.css">
    <link href="https://fonts.googleapis.com/css2?family=Roboto:ital,wght@0,100;0,300;0,400;0,500;0,700;0,900;1,100;1,300;1,400;1,500;1,700;1,900&display=swap" rel="stylesheet">
    <style>
        .product-card {
            border: 1px solid #ccc;
            border-radius: 20px;
            padding: 10px;
            margin: 10px;
            display: inline-block;
            width: 200px;
            background-color: #449544;
            font-family: "Roboto", sans-serif;
            cursor: pointer;
        }

        .product-card:hover {
            background-color: #804606;
        }
    </style>
</head>
<body>
    <h1>Список товаров</h1>
    <?php display_all_products($products); ?>
</body>
</html>